@extends('layouts.app')

@section('content')
<h2 class="text-xl">Create Sale</h2>

<form method="POST" action="{{ route('sales.store') }}" class="mt-4 space-y-3">
  @csrf
  <div>
    <label>Product</label>
    <select name="product_id" class="block w-full border p-2">
      @foreach($products as $p)
        <option value="{{ $p->id }}">{{ $p->name }} (stock: {{ $p->stock }}) - {{ $p->price }}</option>
      @endforeach
    </select>
  </div>

  <div>
    <label>Customer (optional)</label>
    <select name="customer_id" class="block w-full border p-2">
      <option value="">--</option>
      @foreach($customers as $c)
        <option value="{{ $c->id }}">{{ $c->name }}</option>
      @endforeach
    </select>
  </div>

  <div>
    <label>Quantity</label>
    <input name="quantity" type="number" class="block w-full border p-2" min="1" />
  </div>

  <div>
    <button class="px-3 py-1 bg-green-600 text-white rounded">Save Sale</button>
  </div>
</form>
@endsection
