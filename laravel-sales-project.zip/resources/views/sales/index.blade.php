@extends('layouts.app')

@section('content')
<div class="flex justify-between items-center mb-4">
  <h2 class="text-xl font-semibold">Sales</h2>
  <a href="{{ route('sales.create') }}" class="px-3 py-1 bg-blue-600 text-white rounded">New Sale</a>
</div>

<table class="w-full border">
  <thead class="bg-gray-50">
    <tr>
      <th class="p-2 border">Product</th>
      <th class="p-2 border">Customer</th>
      <th class="p-2 border">Quantity</th>
      <th class="p-2 border">Total</th>
      <th class="p-2 border">Date</th>
    </tr>
  </thead>
  <tbody>
    @foreach($sales as $s)
    <tr>
      <td class="p-2 border">{{ $s->product->name }}</td>
      <td class="p-2 border">{{ $s->customer?->name }}</td>
      <td class="p-2 border">{{ $s->quantity }}</td>
      <td class="p-2 border">{{ $s->total_price }}</td>
      <td class="p-2 border">{{ $s->created_at }}</td>
    </tr>
    @endforeach
  </tbody>
</table>
@endsection
