@extends('layouts.app')

@section('content')
<h2 class="text-xl">Add Category</h2>

<form method="POST" action="{{ route('categories.store') }}" class="mt-4 space-y-3">
  @csrf
  <div>
    <label>Name</label>
    <input name="name" class="block w-full border p-2" />
  </div>
  <div>
    <button class="px-3 py-1 bg-green-600 text-white rounded">Save</button>
  </div>
</form>
@endsection
