@extends('layouts.app')

@section('content')
<h2 class="text-xl font-semibold mb-4">Dashboard</h2>

<div class="grid grid-cols-3 gap-4">
  <div class="p-4 border rounded">
    <div class="text-sm text-gray-500">Total Sales</div>
    <div class="text-2xl font-bold">{{ number_format($totalSales, 2) }}</div>
  </div>

  <div class="p-4 border rounded">
    <div class="text-sm text-gray-500">Sales Count</div>
    <div class="text-2xl font-bold">{{ $salesCount }}</div>
  </div>

  <div class="p-4 border rounded">
    <div class="text-sm text-gray-500">Top Products (by stock)</div>
    <ul>
      @foreach($topProducts as $p)
        <li>{{ $p->name }} — stock: {{ $p->stock }}</li>
      @endforeach
    </ul>
  </div>
</div>

<div class="mt-6">
  <h3 class="font-semibold">Low Stock</h3>
  <ul>
  @foreach($lowStock as $p)
    <li>{{ $p->name }} — stock: {{ $p->stock }}</li>
  @endforeach
  </ul>
</div>
@endsection
