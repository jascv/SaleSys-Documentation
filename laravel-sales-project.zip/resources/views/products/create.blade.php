@extends('layouts.app')

@section('content')
<h2 class="text-xl">Add Product</h2>

<form method="POST" action="{{ route('products.store') }}" class="mt-4 space-y-3">
  @csrf
  <div>
    <label>Name</label>
    <input name="name" class="block w-full border p-2" />
  </div>
  <div>
    <label>Category</label>
    <select name="category_id" class="block w-full border p-2">
      <option value="">--</option>
      @foreach($categories as $c)
        <option value="{{ $c->id }}">{{ $c->name }}</option>
      @endforeach
    </select>
  </div>
  <div>
    <label>Supplier</label>
    <select name="supplier_id" class="block w-full border p-2">
      <option value="">--</option>
      @foreach($suppliers as $s)
        <option value="{{ $s->id }}">{{ $s->name }}</option>
      @endforeach
    </select>
  </div>
  <div>
    <label>Price</label>
    <input name="price" class="block w-full border p-2" />
  </div>
  <div>
    <label>Stock</label>
    <input name="stock" class="block w-full border p-2" />
  </div>
  <div>
    <button class="px-3 py-1 bg-green-600 text-white rounded">Save</button>
  </div>
</form>
@endsection
