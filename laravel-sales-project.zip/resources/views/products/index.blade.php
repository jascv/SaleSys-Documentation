@extends('layouts.app')

@section('content')
<div class="flex justify-between items-center mb-4">
  <h2 class="text-xl font-semibold">Products</h2>
  <a href="{{ route('products.create') }}" class="px-3 py-1 bg-blue-600 text-white rounded">Add Product</a>
</div>

<table class="w-full border">
  <thead class="bg-gray-50">
    <tr>
      <th class="p-2 border">Name</th>
      <th class="p-2 border">Category</th>
      <th class="p-2 border">Supplier</th>
      <th class="p-2 border">Price</th>
      <th class="p-2 border">Stock</th>
      <th class="p-2 border">Actions</th>
    </tr>
  </thead>
  <tbody>
    @foreach($products as $p)
    <tr>
      <td class="p-2 border">{{ $p->name }}</td>
      <td class="p-2 border">{{ $p->category?->name }}</td>
      <td class="p-2 border">{{ $p->supplier?->name }}</td>
      <td class="p-2 border">{{ $p->price }}</td>
      <td class="p-2 border">{{ $p->stock }}</td>
      <td class="p-2 border">
        <a href="{{ route('products.edit', $p->id) }}" class="mr-2">Edit</a>
        <form action="{{ route('products.destroy', $p->id) }}" method="POST" style="display:inline">
          @csrf
          @method('DELETE')
          <button type="submit">Delete</button>
        </form>
      </td>
    </tr>
    @endforeach
  </tbody>
</table>
@endsection
