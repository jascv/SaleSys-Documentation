<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Sale;

class SaleSeeder extends Seeder
{
    public function run(): void
    {
        Sale::insert([
            ['product_id'=>1,'customer_id'=>1,'quantity'=>2,'total_price'=>240.00,'created_at'=>now(),'updated_at'=>now()],
            ['product_id'=>2,'customer_id'=>2,'quantity'=>5,'total_price'=>225.00,'created_at'=>now(),'updated_at'=>now()],
        ]);
    }
}
