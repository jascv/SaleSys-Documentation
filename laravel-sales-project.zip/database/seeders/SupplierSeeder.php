<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Supplier;

class SupplierSeeder extends Seeder
{
    public function run(): void
    {
        Supplier::insert([
            ['name'=>'Acme Supplies','contact'=>'09170000000','email'=>'acme@example.com','created_at'=>now(),'updated_at'=>now()],
            ['name'=>'Global Traders','contact'=>'09171111111','email'=>'global@example.com','created_at'=>now(),'updated_at'=>now()],
        ]);
    }
}
