<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Customer;

class CustomerSeeder extends Seeder
{
    public function run(): void
    {
        Customer::insert([
            ['name'=>'Juan Dela Cruz','contact'=>'09172222222','email'=>'juan@example.com','created_at'=>now(),'updated_at'=>now()],
            ['name'=>'Maria Santos','contact'=>'09173333333','email'=>'maria@example.com','created_at'=>now(),'updated_at'=>now()],
        ]);
    }
}
