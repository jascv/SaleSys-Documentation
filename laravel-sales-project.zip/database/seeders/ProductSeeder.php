<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Product;

class ProductSeeder extends Seeder
{
    public function run(): void
    {
        Product::insert([
            ['name'=>'USB Cable','category_id'=>1,'supplier_id'=>1,'price'=>120.00,'stock'=>50,'created_at'=>now(),'updated_at'=>now()],
            ['name'=>'Notebook','category_id'=>2,'supplier_id'=>2,'price'=>45.00,'stock'=>200,'created_at'=>now(),'updated_at'=>now()],
            ['name'=>'Rice (5kg)','category_id'=>3,'supplier_id'=>2,'price'=>250.00,'stock'=>30,'created_at'=>now(),'updated_at'=>now()],
        ]);
    }
}
