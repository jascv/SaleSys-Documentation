To push this template to GitHub:

1. Initialize git:
   git init
   git add .
   git commit -m "Initial commit - Laravel sales template"

2. Create a repository on GitHub, then:
   git remote add origin git@github.com:yourusername/yourrepo.git
   git branch -M main
   git push -u origin main
