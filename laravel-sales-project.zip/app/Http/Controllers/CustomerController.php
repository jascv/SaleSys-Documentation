<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function index() {
        $items = Customer::all();
        return view('customers.index', ['customers'=>$items]);
    }

    public function create() { return view('customers.create'); }

    public function store(Request $request) {
        $request->validate(['name'=>'required']);
        Customer::create($request->all());
        return redirect()->route('customers.index');
    }

    public function edit(Customer $customer) { return view('customers.edit', compact('customer')); }

    public function update(Request $request, Customer $customer) {
        $customer->update($request->all());
        return redirect()->route('customers.index');
    }

    public function destroy(Customer $customer) {
        $customer->delete();
        return redirect()->route('customers.index');
    }
}
