<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use App\Models\Product;
use App\Models\Customer;
use Illuminate\Http\Request;

class SaleController extends Controller
{
    public function index() {
        $sales = Sale::with('product','customer')->get();
        return view('sales.index', compact('sales'));
    }

    public function create() {
        $products = Product::where('stock','>',0)->get();
        $customers = Customer::all();
        return view('sales.create', compact('products','customers'));
    }

    public function store(Request $request) {
        $request->validate([
            'product_id'=>'required',
            'quantity'=>'required|integer|min:1'
        ]);

        $product = Product::findOrFail($request->product_id);
        $total = $product->price * $request->quantity;

        $sale = Sale::create([
            'product_id'=>$request->product_id,
            'customer_id'=>$request->customer_id,
            'quantity'=>$request->quantity,
            'total_price'=>$total,
        ]);

        $product->decrement('stock', $request->quantity);

        return redirect()->route('sales.index');
    }

    public function show(Sale $sale) {
        return view('sales.show', compact('sale'));
    }
}
