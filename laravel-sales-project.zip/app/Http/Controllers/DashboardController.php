<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use App\Models\Product;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $totalSales = Sale::sum('total_price');
        $salesCount = Sale::count();
        $topProducts = Product::orderByDesc('stock')->take(5)->get();
        $lowStock = Product::where('stock', '<', 5)->get();

        return view('dashboard.index', compact('totalSales','salesCount','topProducts','lowStock'));
    }
}
